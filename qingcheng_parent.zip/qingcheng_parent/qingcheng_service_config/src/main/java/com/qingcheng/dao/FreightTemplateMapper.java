package com.qingcheng.dao;

import com.qingcheng.pojo.config.FreightTemplate;
import tk.mybatis.mapper.common.Mapper;

public interface FreightTemplateMapper extends Mapper<FreightTemplate> {

}
