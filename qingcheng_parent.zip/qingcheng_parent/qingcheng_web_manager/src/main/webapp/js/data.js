data={
  "counts": 132,
  "items": [
      {
        "id":1,
         "number":"001",
         "title":"身高" ,
         "type":"检测项目",
         "category":"综合体检",
         "sex":"不限",
         "minAge":0,
         "maxAge":100,
         "price":"0.1",
         "explain":"测量身高"
      },
      {
        "id":2,
        "number":"001",
        "title":"身高" ,
        "type":"检测项目",
        "category":"综合体检",
        "sex":"不限",
        "minAge":0,
        "maxAge":100,
        "price":"0.1",
        "explain":"测量身高"
     },
     {
      "id":3,
      "number":"001",
      "title":"身高" ,
      "type":"检测项目",
      "category":"综合体检",
      "sex":"不限",
      "minAge":0,
      "maxAge":100,
      "price":"0.1",
      "explain":"测量身高"
    },
    {
      "id":4,
      "number":"001",
      "title":"身高" ,
      "type":"检测项目",
      "category":"综合体检",
      "sex":"不限",
      "minAge":0,
      "maxAge":100,
      "price":"0.1",
      "explain":"测量身高"
  }
  ],
  "page":3,
  "pages":53,
  "pagesize":231
}