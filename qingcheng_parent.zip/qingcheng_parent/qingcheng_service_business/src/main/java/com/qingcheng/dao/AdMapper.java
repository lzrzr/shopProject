package com.qingcheng.dao;

import com.qingcheng.pojo.business.Ad;
import tk.mybatis.mapper.common.Mapper;

public interface AdMapper extends Mapper<Ad> {

}
