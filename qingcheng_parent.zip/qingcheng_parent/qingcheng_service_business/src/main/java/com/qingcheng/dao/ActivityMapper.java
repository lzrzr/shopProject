package com.qingcheng.dao;

import com.qingcheng.pojo.business.Activity;
import tk.mybatis.mapper.common.Mapper;

public interface ActivityMapper extends Mapper<Activity> {

}
