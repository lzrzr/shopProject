package com.qingcheng.dao;

import com.qingcheng.pojo.goods.Para;
import tk.mybatis.mapper.common.Mapper;

public interface ParaMapper extends Mapper<Para> {

}
