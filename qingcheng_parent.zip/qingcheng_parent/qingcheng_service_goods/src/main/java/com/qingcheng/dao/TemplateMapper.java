package com.qingcheng.dao;

import com.qingcheng.pojo.goods.Template;
import tk.mybatis.mapper.common.Mapper;

public interface TemplateMapper extends Mapper<Template> {

}
