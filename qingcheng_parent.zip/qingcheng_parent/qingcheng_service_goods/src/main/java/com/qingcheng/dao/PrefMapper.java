package com.qingcheng.dao;

import com.qingcheng.pojo.goods.Pref;
import tk.mybatis.mapper.common.Mapper;

public interface PrefMapper extends Mapper<Pref> {

}
