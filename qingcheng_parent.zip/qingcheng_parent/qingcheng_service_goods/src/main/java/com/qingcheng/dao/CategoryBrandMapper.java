package com.qingcheng.dao;

import com.qingcheng.pojo.goods.CategoryBrand;
import tk.mybatis.mapper.common.Mapper;

public interface CategoryBrandMapper extends Mapper<CategoryBrand> {
}
