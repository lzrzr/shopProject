package com.qingcheng.dao;

import com.qingcheng.pojo.goods.Album;
import tk.mybatis.mapper.common.Mapper;

public interface AlbumMapper extends Mapper<Album> {

}
