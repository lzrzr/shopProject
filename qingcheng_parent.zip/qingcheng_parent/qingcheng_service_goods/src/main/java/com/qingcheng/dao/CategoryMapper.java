package com.qingcheng.dao;

import com.qingcheng.pojo.goods.Category;
import tk.mybatis.mapper.common.Mapper;

public interface CategoryMapper extends Mapper<Category> {

}
