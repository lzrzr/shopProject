package com.qingcheng.dao;

import com.qingcheng.pojo.goods.Sku;
import tk.mybatis.mapper.common.Mapper;

public interface SkuMapper extends Mapper<Sku> {

}
