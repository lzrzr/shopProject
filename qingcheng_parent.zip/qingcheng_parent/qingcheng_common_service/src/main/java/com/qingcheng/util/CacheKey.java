package com.qingcheng.util;

public enum CacheKey {

    AD,//广告
    SKU_PRICE,//价格
    CATEGROY_TREE,//分类
    CATEGORY,//分类
    CART_LIST;//购物车
}
