package com.qingcheng.dao;

import com.qingcheng.pojo.user.Cities;
import tk.mybatis.mapper.common.Mapper;

public interface CitiesMapper extends Mapper<Cities> {

}
