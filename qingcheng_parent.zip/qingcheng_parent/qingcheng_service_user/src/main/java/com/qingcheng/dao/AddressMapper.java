package com.qingcheng.dao;

import com.qingcheng.pojo.user.Address;
import tk.mybatis.mapper.common.Mapper;

public interface AddressMapper extends Mapper<Address> {

}
