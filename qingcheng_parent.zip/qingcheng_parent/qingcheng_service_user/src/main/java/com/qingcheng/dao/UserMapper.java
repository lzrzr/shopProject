package com.qingcheng.dao;

import com.qingcheng.pojo.user.User;
import tk.mybatis.mapper.common.Mapper;

public interface UserMapper extends Mapper<User> {

}
