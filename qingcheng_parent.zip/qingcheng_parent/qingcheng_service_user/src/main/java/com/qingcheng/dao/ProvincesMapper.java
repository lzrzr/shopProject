package com.qingcheng.dao;

import com.qingcheng.pojo.user.Provinces;
import tk.mybatis.mapper.common.Mapper;

public interface ProvincesMapper extends Mapper<Provinces> {

}
