package com.qingcheng.dao;

import com.qingcheng.pojo.user.Areas;
import tk.mybatis.mapper.common.Mapper;

public interface AreasMapper extends Mapper<Areas> {

}
