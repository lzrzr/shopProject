package com.qingcheng.dao;

import com.qingcheng.pojo.order.ReturnOrder;
import tk.mybatis.mapper.common.Mapper;

public interface ReturnOrderMapper extends Mapper<ReturnOrder> {

}
