package com.qingcheng.dao;

import com.qingcheng.pojo.order.ReturnOrderItem;
import tk.mybatis.mapper.common.Mapper;

public interface ReturnOrderItemMapper extends Mapper<ReturnOrderItem> {

}
