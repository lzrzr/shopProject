package com.qingcheng.dao;

import com.qingcheng.pojo.order.OrderItem;
import tk.mybatis.mapper.common.Mapper;

public interface OrderItemMapper extends Mapper<OrderItem> {

}
