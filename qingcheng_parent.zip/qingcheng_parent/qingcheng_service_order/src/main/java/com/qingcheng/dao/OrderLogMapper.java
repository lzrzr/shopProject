package com.qingcheng.dao;

import com.qingcheng.pojo.order.OrderLog;
import tk.mybatis.mapper.common.Mapper;

public interface OrderLogMapper extends Mapper<OrderLog> {

}
