package com.qingcheng.dao;

import com.qingcheng.pojo.order.Preferential;
import tk.mybatis.mapper.common.Mapper;

public interface PreferentialMapper extends Mapper<Preferential> {

}
