package com.qingcheng.dao;

import com.qingcheng.pojo.order.ReturnCause;
import tk.mybatis.mapper.common.Mapper;

public interface ReturnCauseMapper extends Mapper<ReturnCause> {

}
