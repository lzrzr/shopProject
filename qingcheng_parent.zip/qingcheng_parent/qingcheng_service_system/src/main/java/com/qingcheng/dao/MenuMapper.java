package com.qingcheng.dao;

import com.qingcheng.pojo.system.Menu;
import tk.mybatis.mapper.common.Mapper;

public interface MenuMapper extends Mapper<Menu> {

}
