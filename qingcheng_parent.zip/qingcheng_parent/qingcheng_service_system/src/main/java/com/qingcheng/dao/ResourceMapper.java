package com.qingcheng.dao;

import com.qingcheng.pojo.system.Resource;
import tk.mybatis.mapper.common.Mapper;

public interface ResourceMapper extends Mapper<Resource> {

}
