package com.qingcheng.dao;

import com.qingcheng.pojo.system.Role;
import tk.mybatis.mapper.common.Mapper;

public interface RoleMapper extends Mapper<Role> {

}
