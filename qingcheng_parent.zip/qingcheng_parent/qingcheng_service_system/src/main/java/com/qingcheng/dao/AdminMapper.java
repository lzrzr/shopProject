package com.qingcheng.dao;

import com.qingcheng.pojo.system.Admin;
import tk.mybatis.mapper.common.Mapper;

public interface AdminMapper extends Mapper<Admin> {

}
