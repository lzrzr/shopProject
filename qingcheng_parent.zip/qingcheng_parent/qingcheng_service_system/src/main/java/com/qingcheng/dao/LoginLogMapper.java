package com.qingcheng.dao;

import com.qingcheng.pojo.system.LoginLog;
import tk.mybatis.mapper.common.Mapper;

public interface LoginLogMapper extends Mapper<LoginLog> {

}
