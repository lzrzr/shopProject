package com.qingcheng.service.goods;

import com.qingcheng.pojo.goods.Sku;

import java.util.List;
import java.util.Map;

public interface SkuSearchService {


    public Map search(Map<String,String> searchMap);

}
